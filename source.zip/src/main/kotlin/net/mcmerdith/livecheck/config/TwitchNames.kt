package net.mcmerdith.livecheck.config

object TwitchNames : LCConfig("twitch_mapping")